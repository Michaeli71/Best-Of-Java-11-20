package exercises.part4;

import java.io.IOException;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class Exercise04_Teeing 
{
	public static void main(String[] args) throws IOException 
	{
		// In einem Durchlauf Minimum und Maximm finden
		Stream<String> values = Stream.of("CCC", "BB", "A", "DDDD");
		
		// TODO
		//List<Optional<String>> optMinMax = values.collect(teeing(
				    
		//System.out.println(optMinMax); 
	}
}
