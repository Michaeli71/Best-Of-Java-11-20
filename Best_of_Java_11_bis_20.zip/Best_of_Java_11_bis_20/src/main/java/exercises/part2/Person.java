package exercises.part2;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Person 
{
	public int getAge() {
		
		return 0;
	}
}
