package exercises.part6;

import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die
 * Neuerungen in Java 17 LTS und 18"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise03_ThreadingExample {
    public static void main(String[] args) {
        try (var executor = Executors.newFixedThreadPool(50)) {
            IntStream.range(0, 1_000).forEach(i -> {
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(1));

                    System.out.println("Task " + i + " finished!");
                    return i;
                });
            });
        }

        System.out.println("FINISHED");
    }
}
