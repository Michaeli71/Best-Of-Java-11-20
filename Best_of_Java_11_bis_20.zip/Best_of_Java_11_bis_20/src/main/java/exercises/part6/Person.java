package exercises.part6;

import java.time.Duration;
import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die
 * Neuerungen in Java 17 LTS und 18"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
record Person(String firstname, String lastname, LocalDate birthday) {
}

record TravelInfo(LocalDate start, Duration maxTravellingTime) {
}

record City(Integer zipCode, String name) {
}

record Journey(Person person,
               TravelInfo travelInfo,
               City from,
               City to) {
}