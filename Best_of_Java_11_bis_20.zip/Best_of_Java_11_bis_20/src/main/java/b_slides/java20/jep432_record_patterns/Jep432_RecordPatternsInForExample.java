package b_slides.java20.jep432_record_patterns;

import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class Jep432_RecordPatternsInForExample {
    public static void main(String[] args) {
        record City(String name, int inhabitants) {
        }

        var cities = List.of(new City("Zürich", 400_000),
                new City("Kiel", 265_000),
                new City("Köln", 1_000_000),
                new City("Berlin", 3_500_000));

        for (City city : cities)
        {
            System.out.println(city.name() + " has " +
                               city.inhabitants() + " inhabitants");
        }

        for (City(var name, var inhabitants) : cities) {
            System.out.println(name + " has " + inhabitants + " inhabitants");
        }


        var cities2 = Arrays.asList(new City("Zürich", 400_000),
                null,
                new City("Köln", 1_000_000),
                new City("Berlin", 3_500_000));

        for (City(var name, var inhabitants) : cities2) {
            System.out.println(name + " has " + inhabitants + " inhabitants");
        }
    }
}
