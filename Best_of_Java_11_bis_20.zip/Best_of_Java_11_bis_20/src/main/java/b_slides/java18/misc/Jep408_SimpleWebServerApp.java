package b_slides.java18.misc;

import java.net.InetSocketAddress;
import java.nio.file.Path;

import com.sun.net.httpserver.SimpleFileServer;
import com.sun.net.httpserver.SimpleFileServer.OutputLevel;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class Jep408_SimpleWebServerApp
{
    public static void main(final String[] args)
    {
        var address = new InetSocketAddress(8888);
        // BITTE DEN PFAD AUF DEN EIGENEN ANPASSEN
        var path = Path.of("/Users/michaelinden");
        var verbosity = OutputLevel.VERBOSE;

        var server = SimpleFileServer.createFileServer(address, path, verbosity);

        server.start();

        System.out.println("SimpleWebServerApp is up and running");        
    }
}