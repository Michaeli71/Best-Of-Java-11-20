package b_slides.java19.jep405_record_patterns;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class Jep405_RecordPatternsExample
{
    record Point(int x, int y) {}

    static void printCoordinateInfo(Object obj)
    {
        if (obj instanceof Point point)
        {
            int x = point.x();
            int y = point.y();

            System.out.println("x: %d y: %d, sum: %d".formatted(x, y, x + y));
        }
    }

    static void printCoordinateInfoNew(Object obj)
    {
        if (obj instanceof Point(int x, int y))
        {
            System.out.println("x: %d y: %d, sum: %d".formatted(x, y, x + y));
        }
    }
    
    public static void main(String[] args)
    {
        printCoordinateInfo(new Point(72, 71));
        printCoordinateInfoNew(new Point(72, 71));
    }
}