package a_questions;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public record SpecialPerson(String name, LocalDate birthday) {}
